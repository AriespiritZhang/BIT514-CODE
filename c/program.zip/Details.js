detail = {


  init2:function () {

      console.log("This is app2");
      //$(document).on('click', '.btn-detail',detail.detailPro);
      setTimeout(() => {
        console.log("detail执行啦");
        detail.detailPro();
    },500);

  },

  detailPro: async function() {
      var proId = Number(window.location.href.split("?")[1]);
      //console.log(proId);
      //总结：此函数是网页2的初始化函数，目的是为了配合html2显示项目详细信息

      var projectName;
      var projectInittime;
      var projectCategory;
      var projectMode;
      var projectType;
      var projectLocation;
      var projectMoney;
      var projectAttMoney;
      var projectUint;
      var projectContact;
      var projectNowMoney;
      var projectFunderNums;
      var projectdescription;

      var detailsRow = $('#DetailsRow3');
      var fundsTemplate = $('#fundTemplate3');

      App.contracts.Adoption.deployed().then(function(instance1) {

          return instance1.getProname.call(proId);   
      }).then(function(Proname) {

        projectName = String(Proname);
        console.log(projectName);
        fundsTemplate.find('.pro-Name').text(projectName);

        App.contracts.Adoption.deployed().then(function(instance2) {

          return instance2.getProinitime.call(proId);
        }).then(function(Proinittime) {

          projectInittime = String(Proinittime);
          console.log(projectInittime);
          fundsTemplate.find('.pro-Date').text(projectInittime);

          App.contracts.Adoption.deployed().then(function(instance3) {
            return instance3.getProcategory.call(proId);
          }).then(function(Procategory) {

            projectCategory = String(Procategory);
            console.log(projectCategory);
            fundsTemplate.find('.pro-Category').text(projectCategory);

            App.contracts.Adoption.deployed().then(function (instance4){
              return instance4.getPromode.call(proId);
            }).then(function(Promode) {

              projectMode = String(Promode);
              console.log(projectMode);
              fundsTemplate.find('.pro-Mode').text(projectMode);

              App.contracts.Adoption.deployed().then(function(instance5) {
                return instance5.getProtype.call(proId);
              }).then(function(Protype) {

                projectType = String(Protype);
                console.log(projectType);
                fundsTemplate.find('.pro-Type').text(projectType);

                App.contracts.Adoption.deployed().then(function(instance6) {
                  return instance6.getProlocation.call(proId);
                }).then(function(Prolocation) {
                  
                  projectLocation = String(Prolocation);
                  console.log(projectLocation);
                  fundsTemplate.find('.pro-Location').text(projectLocation);

                  App.contracts.Adoption.deployed().then(function(instance11) {
                    return instance11.getPrototalmoney.call(proId);
                  }).then(function (Promoney) {

                    projectMoney = String(Promoney);
                    console.log(projectMoney);
                    fundsTemplate.find('.pro-Money').text(projectMoney);

                    App.contracts.Adoption.deployed().then(function(instance7) {
                      return instance7.getProattr.call(proId);
                    }).then(function(Proattmoney) {

                      projectAttMoney = String(Proattmoney);
                      console.log(projectAttMoney);
                      fundsTemplate.find('.pro-attMoney').text(projectAttMoney);

                      App.contracts.Adoption.deployed().then(function(instance8) {
                        return instance8.getProunit.call(proId);
                      }).then(function(Prouint) {

                        projectUint = String(Prouint);
                        console.log(projectUint);
                        fundsTemplate.find('.pro-Unit').text(projectUint);

                        App.contracts.Adoption.deployed().then(function(instance9) {
                          return instance9.getProcontact.call(proId);
                        }).then(function(Protel){

                          projectContact = String(Protel);
                          console.log(projectContact);
                          fundsTemplate.find('.pro-Tel').text(projectContact);

                          App.contracts.Adoption.deployed().then(function(instance10) {
                            return instance10.getProdescription.call(proId);
                          }).then(function(Prodescription) {
                            
                            projectdescription = String(Prodescription);
                            console.log(projectdescription);
                            fundsTemplate.find('.pro-desciption').text(projectdescription);

                            App.contracts.Adoption.deployed().then(function(instance12){
                              return instance12.getPronowmoney.call(proId);
                            }).then(function(Pronowmoney) {

                              projectNowMoney = String(Pronowmoney);
                              console.log(projectNowMoney);
                              fundsTemplate.find('.pro-nowMoney').text(projectNowMoney);

                              App.contracts.Adoption.deployed().then(function(instance13) {
                                return instance13.getProfundersnum.call(proId);
                              }).then(function(Profunders){

                                projectFunderNums = String(Profunders);
                                console.log(projectFunderNums);
                                fundsTemplate.find('.pro-Funders').text(projectFunderNums);

                                detailsRow.append(fundsTemplate.html());

                              }).catch(function(err) {
                                console.log(err.message);
                              });
                            }).catch(function(err) {
                              console.log(err.message);
                            });
                          }).catch(function(err){
                              console.log(err.message);
                          });
                        }).catch(function(err){
                            console.log(err.message);
                        });
                      }).catch(function(err) {
                          console.log(err.message);
                      });
                    }).catch(function(err) {
                        console.log(err.message);
                    });
                  }).catch(function(err) {
                      console.log(err.message);
                  });
                }).catch(function(err) {
                    console.log(err.message);
                });
              }).catch(function(err) {
                console.log(err.message);
              });
            }).catch(function (err) {
              console.log(err.message);
            });
          }).catch(function (err) {
            console.log(err.message);
          });
        }).catch(function (err) {
          console.log(err.message);
        });
      }).catch(function (err) {
        console.log(err.message);
      });

      return detail.eventBind();
  },
  
  eventBind: function() {

    $(document).on('click', '.btn-transfer', detail.handleFund);
    $(document).on('click', '.close', detail.handleClose);
    $(document).on('click', '.cancelbtn2', detail.handleClose);
  },

  handleFund: async function() {
      
        var proId = Number(window.location.href.split("?")[1]);
        console.log("Transfer to"+ proId);
        //var Addr;
        var pro_Value = $(".transfer").val();

        var transMoney = Number(pro_Value);
        //console.log(transMoney);

        web3.eth.getAccounts(function(erro,accounts) {
            if(erro) {
                console.log(erro.message);
            }

            var account = accounts[0];
            console.log("before transfer");

            App.contracts.Adoption.deployed().then(function(instance){
              
              return instance.getAddress.call(proId);
              }).then(function(Proaddr){
                  let Money = web3.toWei(transMoney,'ether');
                  var message = {from: account, to:Proaddr, value:Money};
                  
                  console.log(message);
                  console.log(Money);

                  web3.eth.sendTransaction(message,(err,res) => {
                    var output = "";
                    if (!err) {
                        output += res;
                        this.txHash=res
                    } else {  
                        output = "Error"+err;
                    }
                    console.log('transfer:',output); 
                    var nowTime = new Date();
                    var Nowtime = String(nowTime);
                    console.log(Nowtime);

                    App.contracts.Adoption.deployed().then(function(instance1) {
                      return instance1.setFund(proId,pro_Value,Nowtime,{from: account});
                  }).then(function(result) {
                    console.log(result);
                  }).catch(function (err) {
                    console.log(err.message);
                  })
            
              }).catch(function(err) {
                  console.log(err.message);
              });
          }).catch(function(err){
              console.log(err.message);
          });
        });

  },

  handleClose: function(event) {
    var modal = document.getElementById('investFund');

    modal.style.display="none";
  }

};

$(function() {
  //该文件的起始执行处，调用init函数完成网页初始化
  $(window).load(function() {
      detail.init2();
      //transferMoney.initWeb3();
  });
});