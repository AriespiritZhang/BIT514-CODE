create = {


    init3: function() {
        //总结：此函数是识别事件函数。在识别出事件后调用事件函数
        //on函数：参数1：事件->点击鼠标 参数2：指定属性->领养按钮 参数3：调用的函数->领养
        console.log("This is create");
        $(document).on('click', '.btn-create', create.createPro); 
    },

    createPro: async function() {

        console.log("createPro");
        var pro_Address = $(".addr").val();
        //console.log(pro_Address);
        var pro_Name = $(".ProjectName").val();
        var pro_Date = $(".InitiationTime").val();

        var options1 = $("#Category option:selected");
        var pro_Category = options1.text();

        var options2 = $("#Mode option:selected");
        var pro_Mode = options2.text();
        console.log(pro_Mode);

        var options3 = $("#Type option:selected");
        var pro_Type = options3.text();
        
        var pro_Location = $(".Location").val();
        var pro_Money = $(".Money").val();
        var pro_attMoney = $(".attMoney").val();
        var pro_Unit = $(".Unit").val();
        var pro_Tel = $(".Contact").val();
        var pro_desciption = $(".description").val();
        console.log(pro_desciption);

        var adoptionInstance;
        
        web3.eth.getAccounts(function(erro,accounts) {
            if(erro) {
                console.log(erro.message);
            }
            var account = accounts[0];
            console.log("before deploye");
            
            App.contracts.Adoption.deployed().then(function(instance) {
            adoptionInstance = instance;
            console.log(adoptionInstance);
            
            return adoptionInstance.addproject(pro_Name,pro_Category,
                        pro_Date,pro_Mode,pro_Type,pro_Location,pro_Money,
                        pro_attMoney,pro_Unit,pro_Tel,pro_desciption,{from: account});
        }).then(function(result){
            return App.getIndex();
        }).catch(function(err) {
            console.log(err.message);
            });
        });

        alert("Congratulations, you have added a projrct seccessfully!");
    }

}; 

$(function() {
    //该文件的起始执行处，调用init函数完成网页初始化
    $(window).load(function() {
        create.init3();
        //transferMoney.initWeb3();
    });
});