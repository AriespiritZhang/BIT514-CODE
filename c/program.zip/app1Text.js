App = {
    web3Provider: null,
    contracts: {},
    ProIndex:0,
  
    init: async function() { 
        console.log("This is app");
          //总结：此函数是网页初始化函数。此函数的作用就是配合html显示项目！
          $.getJSON('../picture.json',function(data){
              var fundsRow2 = $('#FundsRow2');
              var fundsTemplate2 = $('#fundTemplate2');
              
              fundsTemplate2.find('.panel-title').text(data[6].Title);
              fundsTemplate2.find('img').attr('src', data[6].picture);
              console.log("init picture");
              fundsRow2.append(fundsTemplate2.html());
          }); 
        console.log("before initweb3");

        return await App.initWeb3();
    },
  
    initWeb3: async function() {
        //总结：此函数是区块链网络环境配置函数。获取区块链网络服务
        //自我理解一下：App是指运行当前dapp的对象 window是当前打开的浏览器的对象
        if (window.web3) {
        //当前在用的通信服务提供器，如果没有的话则返回null
          App.web3Provider = window.web3.currentProvider;
        }
        // If no injected web3 instance is detected, fall back to Ganache
        //使用ganache提供的通讯提供器
        else {
            App.web3Provider = new Web3.providers.HttpProvider('http://localhost:7545');
        }
        console.log("web ok");
        //创建web3的实例，参数为刚刚取到的
        web3 = new Web3(App.web3Provider);
      
        //初始化智能合约函数
        //这也是initweb3函数return设置成调用函数的原因，initContract函数会继续使用web3provider的值
        return App.initContract();
    },
  
    initContract:  function() {
        //总结：此函数是一个智能合约的初始化函数(n个智能合约有n个这种函数)。
        //获取智能合约的JSON文件并初始化智能合约对象，
        //利用当前智能合约中定义的属性或者函数提供后续操作
    
        // 加载Adoption.json，保存了Adoption的ABI（接口说明）信息及
        //智能合约的JSON文件是部署后的网络(地址)信息，它在编译合约的时候生成ABI，在部署的时候追加网络信息
        $.getJSON('Adoption.json', function(data) {
            // 用Adoption.json数据创建一个可交互的TruffleContract合约对象的实例。
            //trufflecontract是一个用来与智能合约交互的JavaScript库
            var AdoptionArtifact = data;
      
            //用智能合约的JSON初始化智能合约对象
            //App初始化了
            App.contracts.Adoption = TruffleContract(AdoptionArtifact);
      
            // 将智能合约的通信提供方设置为在web3中得到的provider
            App.contracts.Adoption.setProvider(App.web3Provider);
              
            console.log("contract ok");
            // 用智能合约检索和标记被领养的宠物
            //将此函数放在initContrct中的原因是markAdoped会用到JSON数据以及合约对象
            

            return App.getIndex();
        });

        return App.bindEvents();
    },
  
    bindEvents: function() {
        //总结：此函数是识别事件函数。在识别出事件后调用事件函数
        //on函数：参数1：事件->点击鼠标 参数2：指定属性->领养按钮 参数3：调用的函数->领养
        // $(document).on('click', '.btn-transfer', App.handleFund);
        // console.log("handleFund");
        $(document).on('click', '.btn-detail',App.handleDetail);
        console.log("handleDetail");
        $(document).on('click', '.btn-add',App.addProject);
        console.log("addProject");
        $(document).on('click','.Pro-detail',App.checkProdetails);
        // $(document).on('click','next',App.plusSlides);
    },
    
    getIndex: async function(success,account) {
        //总结：此函数是状态函数，是事件函数的结果。利用智能合约中的数据标记被领养的宠物
        
        var adoptionInstance;
        //var i;
        var projectNum;
        
  
        App.contracts.Adoption.deployed().then(function(instance) {
        //调用合约的deploy()方法将其部署到区块链上。其返回的Promise对象 将在成功部署后解析为新的合约实例
        adoptionInstance = instance;
        
        //adoptionInstance.checkMoney();
        // 调用合约的getAdopters(), 用call读取信息不用消耗gas
        return adoptionInstance.getPronum.call();
        //上一个then返回的值会传递给下一个then作为参数
        }).then(function(Pronum) { //合约中的adopters是一个数组
            //console.log(Pronum);
            projectNum = Number(Pronum);
            console.log("The projects number is :"+ projectNum );
            
            for(var i = 0; i < projectNum; i++) {
                App.displayPanel(i);
            }

            for(var j = 0; j < projectNum; j++) {
                App.displayPro(j);
            }

            for(var k = 0;k < projectNum; k++) {
                App.displayInvest(k);
            }

            }).catch(function(err) {

                console.log(err.message);

                });
    },

    displayPanel:function(indexx) {

        var projectName;
        var projectMode;
        var projectInittime;
        var projectLocation;
        var projectType;

        var fundsTemplate = $('#fundTemplate');
        var fundsRow = $('#FundsRow');

        // App.contracts.Adoption.deployed().then(function (instance) {
        //     return instance.getAddress.call(indexx);
        // }).then(function(Proaddr) {
        //     var projectAddr = String(Proaddr);
        //     console.log("The"+indexx+"adrress is :"+Proaddr);
        // }).catch(function(err) {
        //     console.log(err.message);
        // });

        console.log("display: "+indexx);
        App.contracts.Adoption.deployed().then(function(instance1){
            //console.log(a);
            //console.log(instance2)
            return instance1.getProname.call(indexx);
        }).then(function(Proname) {
            
            projectName = String(Proname);
            console.log(projectName);
            
            //console.log(i+0);
            //console.log(a);

            App.contracts.Adoption.deployed().then(function(instance2){
            //console.log(a);
            //console.log(instance2)
            return instance2.getPromode.call(indexx);
            }).then(function(Procmode) {

                projectMode = String(Procmode);
                console.log(projectMode);
                
                //console.log(i+1);
                //console.log(a);

                App.contracts.Adoption.deployed().then(function(instance3){
                //console.log(a);
                //console.log(instance2)
                    return instance3.getProinitime.call(indexx);
                }).then(function(Proinittime) {
                    
                    projectInittime = String(Proinittime);
                    console.log(projectInittime);
                    
                    //console.log(i+1);
                    //console.log(a);

                    App.contracts.Adoption.deployed().then(function(instance4){
                    //console.log(a);
                    //console.log(instance2)
                        return instance4.getProlocation.call(indexx);
                    }).then(function(Prolocation) {

                        projectLocation = String(Prolocation);
                        console.log(projectLocation);
                        
                        //console.log(i+2);
                        //console.log(a);

                        App.contracts.Adoption.deployed().then(function(instance5) {
                            return instance5.getProtype.call(indexx);
                        }).then(function(Protype) {
                            projectType = String(Protype);
                            console.log(projectType);

                            $.getJSON('../picture.json',function(data) {
                                fundsTemplate.find('.panel-title').text(projectName);
                                fundsTemplate.find('.fund-Mode').text(projectMode);
                                fundsTemplate.find('.fund-InitTime').text(projectInittime);
                                fundsTemplate.find('.fund-location').text(projectLocation);
                                fundsTemplate.find('.btn-detail').attr('data-id',indexx);
                                fundsTemplate.find('.btn-fund').attr('data-id',indexx);
    
                                if (projectType == "Culture and Entertainment") {

                                    fundsTemplate.find('img').attr('src',data[0].picture);

                                }else if (projectType == "Education") {

                                    fundsTemplate.find('img').attr('src',data[1].picture);

                                }else if (projectType == "Medical and Health") {

                                    fundsTemplate.find('img').attr('src',data[2].picture);

                                }else if (projectType == "Real Estate") {

                                    fundsTemplate.find('img').attr('src',data[3].picture);

                                }else if(projectType == "Web Technology") {

                                    fundsTemplate.find('img').attr('src',data[4].picture);

                                }else{

                                    fundsTemplate.find('img').attr('src',data[5].picture);

                                }

                                fundsRow.append(fundsTemplate.html());

                                });

                            }).catch(function (err) {
                                console.log(err.message);
                            });

                        }).catch(function (err) { 
                                console.log(err.message);
                        });

                    }).catch(function (err) { 
                        console.log(err.message);
                    });

                }).catch(function (err) { 
                        console.log(err.message);
                });

            }).catch(function (err) { 
                    console.log(err.message);
            });

        
    },

    displayPro :function(index2){

        console.log("This is displayPro" + index2);

        web3.eth.getAccounts(function(err,acoounts) {
            if(err) {
                console.log(console.err.message);
            }

            var account = acoounts[0];
            console.log(account);
            console.log("before displayPro");

            var projectName2;
            var projectFundNum2;
            var projectFundMoney2;
            var projectType2;

            //var fundsTemplate2 = $('#TableInform');
            var fundsRow2 = document.getElementById('TableBody');
            var tr = document.createElement('tr');
            var tdName = document.createElement('td');
            var tdFundnum = document.createElement('td');
            var tdFundmoney = document.createElement('td');
            var tdFunddetail = document.createElement('td');

            App.contracts.Adoption.deployed().then(function (instance) {
                return instance.getAddress.call(index2);
            }).then(function(Proaddr) {
                console.log(Proaddr);
                if(Proaddr == account){

                    console.log("display_pro:" + account);
                    App.contracts.Adoption.deployed().then(function(instance2) {
                        return instance2.getProname.call(index2);
                    }).then(function(proname2) {
                        projectName2 = String(proname2);
                        tdName.innerHTML = projectName2;
                        console.log(projectName2);

                        App.contracts.Adoption.deployed().then(function(instance3){
                            return instance3.getProfundersnum.call(index2);
                        }).then(function(profundersnum) {
                            projectFundNum2 = String(profundersnum);
                            tdFundnum.innerHTML = projectFundNum2;
                            console.log(projectFundNum2);

                            App.contracts.Adoption.deployed().then(function(instance4) {
                                return instance4.getPronowmoney.call(index2);
                            }).then(function(pronowmoney) {
                                projectFundMoney2 = String(pronowmoney);
                                tdFundmoney.innerHTML = projectFundMoney2;
                                console.log(projectFundMoney2);

                                App.contracts.Adoption.deployed().then(function(instance5) {
                                    return instance5.getProtype.call(index2);
                                }).then(function(protype) {
                                    projectType2 = String(protype);
                                    console.log(projectType2);

                                    tdFunddetail.innerHTML += '<button class="btn btn-default Pro-detail" data-id =\'' + index2 +'\' type = "button" >Detail</button>';
                                    //onclick="App.checkProdetails(\''+index2+'\');"

                                    //tdFunddetail.appendChild(btdetail);
                                    console.log(tdFunddetail);
                                    tr.appendChild(tdName);
                                    tr.appendChild(tdFundnum);
                                    tr.appendChild(tdFundmoney);
                                    tr.appendChild(tdFunddetail);
                                    fundsRow2.appendChild(tr);

                                    console.log("Mypro load finish");
                                    
                            
                                }).catch(function(err) {
                                    console.log(err.message);
                                });
                            }).catch(function(err) {
                                console.log(err.message);
                            });
                        }).catch(function(err) {
                            console.log(err.message);
                        });

                    }).catch(function(err) {
                        console.log(err.message);
                    });
                } //if
            }).catch(function(err) {
                console.log(err.message);
            });

            console.log("This is MyPro");
        });
    },

    checkProdetails :function(event) {
        var proID = parseInt($(event.target).data('id'));

        App.contracts.Adoption.deployed().then(function(instance) {
            return instance.getPronum.call();
        }).then(function(result) {
            window.location.href = "index3.html?"+proID;
        }).catch(function(err) {
            console.log(err.message);
        });

        console.log("hava into");

    },

    displayInvest :function(index3) {

        console.log("This is displayInvest");
    
            var projectFundNum3;

            App.contracts.Adoption.deployed().then(function (instance) {
                return instance.getPrototalfunds.call(index3);
            }).then(function(fundnum) {
                projectFundNum3 = Number(fundnum);
                console.log(projectFundNum3);

                for(var i = 0; i < projectFundNum3; i++){
                    App.checkFunddetail(index3,i);
                }
                
            }).catch(function(err) {
                console.log(err.message);
            });

            console.log("This is MyPro");
    },

    checkFunddetail: function(index4,funderIndex) {

        console.log(index4);
        console.log(funderIndex);

        var projectName3;
        var projectFundMoney3;
        var projectFundTime3;

        //var fundsTemplate2 = $('#TableInform');
        var fundsRow2 = document.getElementById('TableBody3');
        var tr = document.createElement('tr');
        var tdName2 = document.createElement('td');
        var tdFundmoney2 = document.createElement('td');
        var tdFundtime2 = document.createElement('td');

        web3.eth.getAccounts(function(err,acoounts) {
            if(err) {
                console.log(console.err.message);
            }

            var account = acoounts[0];
            console.log(account);
            console.log("before displayInvest");

            App.contracts.Adoption.deployed().then(function (instance) {
                return instance.getFunderaddr.call(index4,funderIndex);
            }).then(function(investaddr) {
                if(account == investaddr) {
                    console.log(account);
                    App.contracts.Adoption.deployed().then(function (instance1) {
                        return instance1.getProname.call(index4);
                    }).then(function(investname) {
                        projectName3 = String(investname);
                        console.log(projectName3);
                        tdName2.innerHTML = projectName3;

                        App.contracts.Adoption.deployed().then(function(instance2) {
                            return instance2.getFunderfunds2(index4,funderIndex);
                        }).then(function (investmoney) {
                            projectFundMoney3 = Number(investmoney);
                            console.log(projectFundMoney3);
                            tdFundmoney2.innerHTML = projectFundMoney3;

                            App.contracts.Adoption.deployed().then(function(instance3) {
                                return instance3.getFundtime.call(index4,funderIndex);
                            }).then(function(investtime) {
                                projectFundTime3 = String(investtime);
                                console.log(projectFundTime3);
                                tdFundtime2.innerHTML = projectFundTime3;

                                tr.appendChild(tdName2);
                                tr.appendChild(tdFundmoney2);
                                tr.appendChild(tdFundtime2);
                                fundsRow2.appendChild(tr);

                            }).catch(function(err) {
                                console.log(err.message);
                            });

                        }).catch(function(err) {
                            console.log(err.message);
                        });

                    }).catch(function(err) {
                        console.log(err.message);
                    });
                }   
            }).catch(function(err) {
                console.log(err.message);
            });

        });
    },
  
    handleDetail:function(event) {
        //总结：此函数是事件函数。得知用户按下详情键,目的是为了跳转页面并显示详情。
        console.log("detail project");
        var proID = parseInt($(event.target).data('id'));

        App.contracts.Adoption.deployed().then(function(instance) {
            return instance.getPronum.call();
        }).then(function(result) {
            window.location.href = "index2.html?"+proID;
        }).catch(function(err) {
            console.log(err.message);
        });
        //window.open("index2.html");
    },

    addProject: function(event) {
        //总结：此函数是事件函数。用户添加一个新的项目。
        var adoptionInstance;
        var petId;
        console.log("add project");

        App.contracts.Adoption.deployed().then(function(instance) {
        //调用合约的deploy()方法将其部署到区块链上。其返回的Promise对象 将在成功部署后解析为新的合约实例
        adoptionInstance = instance;
        
        //adoptionInstance.checkMoney();
        // 调用合约的getAdopters(), 用call读取信息不用消耗gas
        return adoptionInstance.getPronum.call();
        //上一个then返回的值会传递给下一个then作为参数
        }).then(function(Pronum) { //合约中的adopters是一个数组
            petId = Number(Pronum);
            window.location.href = "index4.html?"+petId;
        }).catch(function(err) {
            console.log(err.message);
        });
        
    }
  
};
  
$(function() {
    //该文件的起始执行处，调用init函数完成网页初始化
    $(window).load(function() {
      App.init();
    });
  });
  