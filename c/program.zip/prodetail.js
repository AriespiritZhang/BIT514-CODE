prodetail = {

    init: function() {
        console.log("This is prodetails");
        setTimeout(() => {
            console.log("prodetail执行啦");
            prodetail.funderInform();
        },500);
    },

    funderInform: async function() {
        var proId = Number(window.location.href.split("?")[1]);
        console.log(proId);

        var fundNum;
        App.contracts.Adoption.deployed().then(function (instance) {
            return instance.getPrototalfunds.call(proId);
        }).then(function (Fundnum) {

            fundNum = Number(Fundnum);
            console.log(fundNum);
            for(var i = 0; i < fundNum; i++) {
                console.log(i);
                prodetail.displayfunderInform(i);
            }
            console.log("Before into");
            //var fundsRow = document.getElementById('DetailsRow4');
            var fundsTemplate = document.getElementById('fundTemplate4');
            console.log(fundsTemplate);
            //fundsRow.appendChild(fundsTemplate);
            //console.log(fundsRow);
            //fundsRow.find('#fundTemplate4').style.display = "block";

        }).catch(function(err) {
            //console.log(err);
        });
    },

    displayfunderInform: function(funderIndex) {
        var proId = Number(window.location.href.split("?")[1]);
        console.log(proId);
        console.log(funderIndex);

        var Proname;
        var Funderaddr;
        var Fundermoney;
        var FunderTime;

        var TableBody = document.getElementById('TableBody2');
        var fundsTemplate = $('#fundTemplate4');
        var tr = document.createElement('tr');
        var tdFundaddr = document.createElement('td');
        var tdFundmoney = document.createElement('td');
        var tdFundTime = document.createElement('td');

        App.contracts.Adoption.deployed().then(function (instance) {
            return instance.getProname.call(proId);
        }).then(function(proname) {
            Proname = String(proname);
            console.log(Proname);
            fundsTemplate.find('.proName2').text(Proname);

        }).catch(function (err) {
            console.log(err.message);
        });

        App.contracts.Adoption.deployed().then(function (instance) {
            return instance.getFunderaddr.call(proId,funderIndex);
        }).then(function(funaddr) {
            Funderaddr = String(funaddr);
            console.log(Funderaddr);
            tdFundaddr.innerHTML = Funderaddr;

            App.contracts.Adoption.deployed().then(function(instance1) {
                return instance1.getFunderfunds2.call(proId,funderIndex);
            }).then(function (funmoney) {
                Fundermoney = String(funmoney);
                console.log(Fundermoney);
                tdFundmoney.innerHTML = Fundermoney;

                App.contracts.Adoption.deployed().then(function(instance2) {
                    return instance2.getFundtime.call(proId,funderIndex);
                }).then(function(funtime) {
                    FunderTime = String(funtime);
                    console.log(FunderTime);
                    tdFundTime.innerHTML = FunderTime;

                    tr.appendChild(tdFundaddr);
                    tr.appendChild(tdFundmoney);
                    tr.appendChild(tdFundTime);

                    TableBody.appendChild(tr);
                    console.log(tr);
                }).catch(function (err) {
                    console.log(err.message);
                });
            }).catch(function(err) {
                console.log(err.message);
            });
        }).catch(function(err) {
            console.log(err.message);
        });
        
    }

};

$(function() {
    //该文件的起始执行处，调用init函数完成网页初始化
    $(window).load(function() {
        prodetail.init();
        //transferMoney.initWeb3();
    });
  });