App = {
    slideIndex : 1,

    init: function () {

        $(".menu").mousedown(function(){
            $(this).toggleClass("menu_closed");
            
            if($(this).hasClass("menu_closed")) {
                $(".main.menu_button").text("More");
                var dis_mis = document.getElementById('display_music');
                dis_mis.style.display = "none";

                var dis_pla = document.getElementById('display_places');
                dis_pla.style.display = "none";
                

            } else {
                $(".main.menu_button").text("Close");

                var dis_mis = document.getElementById('display_music');
                dis_mis.style.display = "block";

                var dis_pla = document.getElementById('display_places');
                dis_pla.style.display = "block";
            }
        });

        return App.bindEvents();

    },

    bindEvents: function() {

        $(document).on('click', '.display_mus', App.getAddr_Pro);
        $(document).on('click', '.display_pla', App.getAddr_Invest);
    },

    getAddr_Pro: async function() {



        web3.eth.getAccounts(function(err,acoounts) {
            if(err) {
                console.log(console.err.message);
            }

            var account = acoounts[0];
            console.log("before Pro");

            App.contracts.Adoption.deployed().then(function(instance) {

                return instance.getPronum.call();

            }).then(function(Pro_num) {

                var num = Number(Pro_num);
                for(var i = 0; i < num; i++){

                    App.displayPro(i,account);
                }

            }).catch(function(err) {
                console.log(err.message);
            });

        });

    },

    displayPro: function(index2,account) {

        var projectName2;
        var projectFundNum2;
        var projectFundMoney2;
        var projectType2;

        var fundsTemplate2 = $('#proSlider');
        var fundsRow2 = $('#proSliderContain');

        App.contracts.Adoption.deployed().then(function (instance) {
            return instance.getAddress.call(index2);
        }).then(function(Proaddr) {

            if(account == Proaddr){

                console.log("display_pro:" + account);
                App.contracts.Adoption.deployed().then(function(instance2) {
                    return instance2.getProname.call(index2);
                }).then(function(proname2) {
                    projectName2 = String(proname2);
                    console.log(projectName2);

                    App.contracts.Adoption.deployed().then(function(instance3){
                        return instance3.getProfundersnum.call(index2);
                    }).then(function(profundersnum) {
                        projectFundNum2 = String(profundersnum);
                        console.log(projectFundNum2);

                        App.contracts.Adoption.deployed().then(function(instance4) {
                            return instance4.getPronowmoney.call(index2);
                        }).then(function(pronowmoney) {
                            projectFundMoney2 = String(pronowmoney);
                            console.log(projectFundMoney2);

                            App.contracts.Adoption.deployed().then(function(instance5) {
                                return instance5.getProtype.call(index2);
                            }).then(function(protype) {
                                projectType2 = String(protype);
                                console.log(projectType2);

                                $.getJSON('../picture.json',function(data) {
                                    fundsTemplate2.find('.Pro-Name').text(projectName2);
                                    fundsTemplate2.find('.Pro-num').text(projectFundNum2);
                                    fundsTemplate2.find('.Pro-money').text(projectFundMoney2);
                                    fundsTemplate2.find('.Pro-detail').attr('data-id',index2);

                                    if (projectType2 == "Culture and Entertainment") {

                                        fundsTemplate2.find('img').attr('src',data[0].picture);
    
                                    }else if (projectType2 == "Education") {
    
                                        fundsTemplate2.find('img').attr('src',data[1].picture);
    
                                    }else if (projectType2 == "Medical and Health") {
    
                                        fundsTemplate2.find('img').attr('src',data[2].picture);
    
                                    }else if (projectType2 == "Real Estate") {
    
                                        fundsTemplate2.find('img').attr('src',data[3].picture);
    
                                    }else if(projectType2 == "Web Technology") {
    
                                        fundsTemplate2.find('img').attr('src',data[4].picture);
    
                                    }else{
    
                                        fundsTemplate2.find('img').attr('src',data[5].picture);
    
                                    }

                                    fundsRow2.append(fundsTemplate2.html());
                                });
                            }).catch(function(err) {
                                console.log(err.message);
                            });
                        }).catch(function(err) {
                            console.log(err.message);
                        });
                    }).catch(function(err) {
                        console.log(err.message);
                    });

                }).catch(function(err) {
                    console.log(err.message);
                });

            }

        }).catch(function(err) {
            console.log(err.message);
        });

        console.log("This is MyPro");
        //$(document).on('click', '.btn-detail',detail.detailPro);
        setTimeout(() => {
            console.log("detail执行啦");
            App.showSlides(slideIndex);
        },500);
        
    },

    showSlides:function(n) {

        var i;
        var slides = document.getElementsByClassName("mySlides");
        var dots = document.getElementsByClassName("dot");
        if (n > slides.length) {slideIndex = 1;}    
        if (n < 1) {slideIndex = slides.length;}

        for (i = 0; i < slides.length; i++) {
            slides[i].style.display = "none";  
        }

        for (i = 0; i < dots.length; i++) {
            dots[i].className = dots[i].className.replace(" active", "");
        }

        slides[slideIndex-1].style.display = "block";  
        dots[slideIndex-1].className += " active";
    },

    plusSlides: function() {
        showSlides(slideIndex += n);
    },

    currentSlide:function(n) {
        showSlides(n);
    }

}

$(function() {
    $(window).load(function() {
        App.init();
    });
});