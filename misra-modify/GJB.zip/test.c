#include<stdio.h>
// int zdata = 0;

// extern int zdata = 1;

int main(void){
    unsigned int x,y;
    x = 0x00001;
    y = x <<3;
}
// int zdata = 1;
// void func (short a, float b){
// }